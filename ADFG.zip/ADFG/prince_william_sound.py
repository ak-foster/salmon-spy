from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import datetime
import time
import os

#setup download folder and selenium properties
cwd = os.getcwd()
cwd = cwd.replace('/','//')
chrome_options = webdriver.ChromeOptions()
prefs = {'download.default_directory' : cwd}
chrome_options.add_experimental_option('prefs', prefs)
chrome_options.add_argument("--headless")
chrome_options.add_argument("--window-size=1920x1080")
driver = webdriver.Chrome(chrome_options=chrome_options)
base_url = 'http://www.adfg.alaska.gov/index.cfm?adfg=commercialbyareapws.harvestsummary'

try:
	os.mkdir('Results')
except:
	pass

def enable_download_in_headless_chrome(driver, download_dir):
    # add missing support for chrome "send_command"  to selenium webdriver
    driver.command_executor._commands["send_command"] = ("POST", '/session/$sessionId/chromium/send_command')
    params = {'cmd': 'Page.setDownloadBehavior', 'params': {'behavior': 'allow', 'downloadPath': download_dir}}
    command_result = driver.execute("send_command", params)

enable_download_in_headless_chrome(driver, 'Results/Prince William Sound')

#go to url and select frame that contains data
driver.get(base_url)
iframe = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.TAG_NAME, 'iframe')))
driver.switch_to_frame(iframe)

#press export link
report_links = WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.NAME, 'ReportLinkMenu')))
for link in report_links:
	if 'Export' in link.text:
		link.click()

#complicated process to ensure CSV format is selected
attempts = 1
while(attempts != 5):
	try:
		cells = driver.find_elements_by_class_name('NQWMenuItemWIconMixin')
		data_btn = cells[0]
		for cell in cells:
			if 'Data' in cell.text:
				data_btn = cell
				break
		if 'Data' in data_btn.text:
			break
		else:
			time.sleep(2)
			attempts += 1
	except:
		time.sleep(2)
		attempts += 1
data_btn.click()
if attempts == 5:
	print('Error clicking data button.')
attempts = 1
while(attempts != 5):
	try:
		cells = driver.find_elements_by_class_name('NQWMenuItemWIconMixin')
		csv_btn = cells[0]
		for cell in cells:
			if 'CSV' in cell.text:
				csv_btn = cell
				break
		if 'CSV' in csv_btn.text:
			break
		else:
			time.sleep(2)
			attempts += 1
	except:
		time.sleep(2)
		attempts += 1
csv_btn.click()
if attempts == 5:
	print('Error clicking csv button.')
while(attempts != 5):
	try:
		confirmation_box = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'dialogTopBottomBorder')))
		okay_btn = WebDriverWait(confirmation_box, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'masterToolbarTextButton')))
		if okay_btn.text == 'OK':
			break
		else:
			time.sleep(2)
			attempts += 1
	except:
		time.sleep(2)
		attempts += 1
if attempts == 5:
	print('Error clicking okay button.')

#get date accessed, ie: today, and rename file based on this date
month = datetime.datetime.today().month
day = datetime.datetime.today().day
year = datetime.datetime.today().year
file = [x for x in os.listdir((str(cwd) + '/Results/Prince William Sound')) if x.endswith(".csv")]
file = file[0]
os.rename('Results/Prince William Sound/' + file, 'Results/Prince William Sound/' + 'PWS Harvest Estimates - ' + str(month) + '-' + str(day) + '-' + str(year) + '.csv')

print('Done.')
driver.close()


