from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time
import os

#setup download folder and selenium properties
cwd = os.getcwd()
cwd = cwd.replace('/','//')
chrome_options = webdriver.ChromeOptions()
prefs = {'download.default_directory' : cwd}
chrome_options.add_experimental_option('prefs', prefs)
chrome_options.add_argument("--headless")
chrome_options.add_argument("--window-size=1920x1080")
driver = webdriver.Chrome(chrome_options=chrome_options)
url = 'http://www.oceanak.adfg.alaska.gov/analytics/saw.dll?PortalPages&PortalPath=%2Fshared%2FCommercial%20Fisheries%2FPublic%20Web%2FRegion%20II%2FSalmon%2FDaily%20Run%20Summary%20Public&NQUser=public_bi_user&NQPassword=No12rules&options=fdr'

try:
	os.mkdir('Results')
	os.mkdir('Results/Bristol Bay')
except:
	pass

#given driver and run date button, returns list ofdates in WebElement format
def getDates(driver):
	dates = []
	run_date_btn = driver.find_element_by_class_name('promptTextField')
	run_date_btn.click()
	attempts = 1
	while(attempts != 5):
		drop_down_list = driver.find_element_by_class_name('DropDownValueList')
		if len(drop_down_list.text) > 20:
			break
		else:
			time.sleep(2)
			attempts += 1
	if attempts == 5:
		print('Error collecting dates from dropdown list.')
	else:
		dates = drop_down_list.find_elements_by_class_name('promptMenuOption')
	return dates

#click the day that follows the day provided
def clickNextDate(driver, date_text):
	dates = getDates(driver)
	itr = 0
	for date in dates:
		if date_text == date.get_attribute('title'):
			break
		itr += 1
	orig_page_source = driver.page_source
	for i in range(itr, len(dates)):
		if 'visible' in dates[i].find_element_by_class_name('promptMenuOptionStatusIcon').get_attribute('style'):
			try:
				date = dates[i+1]
			except: #end of dates
				return -1
				print('Last day.')
	date.click()
	while(True):
		if driver.page_source != orig_page_source:
			return 1

#acquire new elements no page and wait for them to load
def pressApplyBtn(driver):
	apply_btn = driver.find_element_by_class_name('promptApplyButton')
	apply_btn.click()
	attempts = 1
	while(attempts != 5):
		try:
			day = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'promptTextField'))).get_attribute('title')
			downloadable_content = driver.find_elements_by_class_name('ViewContent')
			for i in range(1, len(downloadable_content)):
				try:
					if day in driver.find_elements_by_class_name('ViewContent')[i].text:
						return
					else:
						time.sleep(5)
						apply_btn = driver.find_element_by_class_name('promptApplyButton')
						apply_btn.click()
						attempts += 1
				except:
					pass
		except:
			time.sleep(5)
			attempts += 1
		if attempts == 5:
			print('Error clicking apply button.')

#wait for content to load and then select each downloadable element and download
def downloadContent(driver):
	time.sleep(5)
	downloadable_content = WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'ViewContent')))
	for content in downloadable_content:
		export_link = content.find_element_by_name('ReportLinkMenu')
		export_link.click()
		attempts = 1
		while(attempts != 5):
			try:
				cells = driver.find_elements_by_class_name('NQWMenuItemWIconMixin')
				data_btn = cells[0]
				for cell in cells:
					if 'Data' in cell.text:
						data_btn = cell
						break
				if 'Data' in data_btn.text:
					break
				else:
					time.sleep(2)
					attempts += 1
			except:
				time.sleep(2)
				attempts += 1
		data_btn.click()
		if attempts == 5:
			print('Error clicking data button.')
		attempts = 1
		while(attempts != 5):
			try:
				cells = driver.find_elements_by_class_name('NQWMenuItemWIconMixin')
				csv_btn = cells[0]
				for cell in cells:
					if 'CSV' in cell.text:
						csv_btn = cell
						break
				if 'CSV' in csv_btn.text:
					break
				else:
					time.sleep(2)
					attempts += 1
			except:
				time.sleep(2)
				attempts += 1
		csv_btn.click()
		if attempts == 5:
			print('Error clicking csv button.')
		attempts = 1
		while(attempts != 5):
			try:
				confirmation_box = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'dialogTopBottomBorder')))
				okay_btn = WebDriverWait(confirmation_box, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'masterToolbarTextButton')))
				if okay_btn.text == 'OK':
					break
				else:
					time.sleep(2)
					attempts += 1
			except:
				time.sleep(2)
				attempts += 1
		if attempts == 5:
			print('Error clicking okay button.')
		else:
			okay_btn.click()

def dateAlreadyDownloaded(date_text):
	directories = str([x[0] for x in os.walk(cwd)])
	if date_text.replace('/', '-') in directories:
		return True
	return False

def enable_download_in_headless_chrome(driver, download_dir):
    # add missing support for chrome "send_command"  to selenium webdriver
    driver.command_executor._commands["send_command"] = ("POST", '/session/$sessionId/chromium/send_command')
    params = {'cmd': 'Page.setDownloadBehavior', 'params': {'behavior': 'allow', 'downloadPath': download_dir}}
    command_result = driver.execute("send_command", params)

enable_download_in_headless_chrome(driver, 'Results/Bristol Bay')

#go to url and get base information, ie: dates to grab data from
driver.get(url)
run_date_btn = WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.CLASS_NAME, 'promptTextField')))
dates = getDates(driver)
date_text_list = []
for date in dates:
	date_text_list.append(date.get_attribute('title'))

first_day = date_text_list[0]

#main loop to get data. Only grabs information from new dates
itr = 0
endLoop = 0
while(endLoop != -1):
	print('Count: ' + str(itr + 1) + ' / ' + str(len(dates)))
	if not dateAlreadyDownloaded(date_text_list[itr]):
		if first_day != date_text_list[itr]:
			endLoop = clickNextDate(driver, date_text_list[itr])
			pressApplyBtn(driver)
		try:
			enable_download_in_headless_chrome(driver, 'Results/Bristol Bay/' + str(date_text_list[itr].replace('/', '-')))
			downloadContent(driver)
			day_text = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'promptTextField'))).get_attribute('title')
			print(day_text)
		except:
			print('Error on: ' + day_text)
	itr += 1
	if itr >= len(dates):
		break

print('Done.')
driver.close()
